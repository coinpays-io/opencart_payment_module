<?php
// Text
$_['text_title']                                = 'CoinPays Crypto Payment';
$_['text_total']                                = 'Installment Difference';

// Error
$_['error_coinpays_checkout_curl']                 = 'PHP CURL Extension must be activated in your server.';
$_['error_coinpays_checkout_transaction_save']     = 'An error occurred when transaction save.';
$_['error_coinpays_checkout_transaction_install']  = 'CoinPays module not installed properly. Please reinstall again.';
$_['error_coinpays_iframe_failed']                 = 'COINPAYS IFRAME failed. Reason => ';