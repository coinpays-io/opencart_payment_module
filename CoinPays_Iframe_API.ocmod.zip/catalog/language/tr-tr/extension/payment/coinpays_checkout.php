<?php
// Text
$_['text_title']                                = 'CoinPays Kripto Ödeme';
$_['text_total']                                = 'Vade Farkı';

// Error
$_['error_coinpays_checkout_curl']                 = 'PHP CURL eklentisi bu serverda aktif değil..';
$_['error_coinpays_checkout_transaction_save']     = 'İşlem kayıt edilirken bir sorun oluştu.';
$_['error_coinpays_checkout_transaction_install']  = 'CoinPays modülü doğru kurulmamış. Lütfen yeniden kurulum yapın.';
$_['error_coinpays_iframe_failed']                 = 'COINPAYS IFRAME hatası. Hata => ';